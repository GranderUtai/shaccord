extends CanvasLayer

@onready var pji := $ProjectInfo
@onready var sted := $StaveEditor
@onready var thed := $ThemeEditor
@export var pjd: Node

func _ready():
	pji.about_to_popup.connect(pji_open)
	pji.close_requested.connect(func(): pji.hide())
	
	sted.about_to_popup.connect(sted_open)
	sted.close_requested.connect(func(): sted.hide())
	
	thed.about_to_popup.connect(thed_open)
	thed.close_requested.connect(func(): thed.hide())

func pji_open():
	if pji.get_meta("generated") == false:
		pji.set_meta("generated", true)
		pji.get_node("vbox/bpm/SpinBox").value_changed.connect(func(v):
			pjd.project.bpm = v
		)
		pji.get_node("vbox/timesig/HBoxContainer/nom").value_changed.connect(func(v):
			pjd.project.time_sig[0] = int(v)
			%Content.get_node("Grid").queue_redraw()
		)
		pji.get_node("vbox/timesig/HBoxContainer/denom").value_changed.connect(func(v):
			pjd.project.time_sig[1] = int(v)
			%Content.get_node("Grid").queue_redraw()
		)
	pji.get_node("vbox/bpm/SpinBox").value = pjd.project.bpm
	pji.get_node("vbox/timesig/HBoxContainer/nom").value = pjd.project.time_sig[0]
	pji.get_node("vbox/timesig/HBoxContainer/denom").value = pjd.project.time_sig[1]

func sted_open():
	var vbox = sted.get_node("vbox")
	var sample = vbox.get_node("sample")
	var add = vbox.get_node("add")
	sample.visible = false
	if not sted.get_meta("generated"):
		add.pressed.connect(func():
			pjd.project.staves.append("")
			var row = _create_stave_row(
				sample,
				pjd.project.staves.size() - 1
			)
			vbox.move_child(row, vbox.get_child_count() - 1)
			rerenderstaves()
		)
		sted.set_meta("generated", true)
	for child in vbox.get_children():
		if child == sample or child == add:
			continue
		child.queue_free()
	for i in range(pjd.project.staves.size()):
		var row = _create_stave_row(sample, i)
		vbox.move_child(row, vbox.get_child_count() - 1)
func _create_stave_row(sample: Control, index: int) -> Control:
	var row = sample.duplicate()
	row.visible = true
	row.name = str(index)
	var input = row.get_node("input")
	var delete = row.get_node("delete")
	input.text = pjd.project.staves[index]
	input.text_changed.connect(func(text):
		pjd.project.staves[index] = text
		rerenderstaves()
	)
	delete.pressed.connect(func():
		pjd.project.staves.remove_at(index)
		row.queue_free()
		rerenderstaves()
		sted_open()
	)
	sted.get_node("vbox").add_child(row)
	return row

func thed_open():
	var vbox = thed.get_node("vbox")
	var sample = vbox.get_node("sample")
	sample.visible = false
	
	if thed.get_meta("generated") == false:
		for key in pjd.theme:
			var value = pjd.theme[key]
			var row = sample.duplicate()
			row.visible = true
			row.name = key
			vbox.add_child(row)
			row.get_node("Label").text = key
			_setup_theme_control(row, key, value)
		thed.set_meta("generated", true)
	else:
		_update_theme_rows(vbox)
func _update_theme_rows(vbox: VBoxContainer):
	for row in vbox.get_children():
		if row.name == "sample":
			continue
		var value = pjd.theme[row.name]
		if value is Color:
			row.get_node("cpb").color = value
		elif value is float or value is int:
			row.get_node("SpinBox").value = value
	#for some reason the bg colorpicker must be updated manually. dont ask
	vbox.get_node_or_null("bg").get_node("cpb").color = pjd.theme.bg
func _setup_theme_control(row: Control, key: String, value):
	if value is Color:
		row.get_node("SpinBox").queue_free()
		var picker = row.get_node("cpb")
		picker.color = value
		picker.color_changed.connect(func(v): rerender(key, v))
	elif value is float or value is int:
		row.get_node("cpb").queue_free()
		var spinbox = row.get_node("SpinBox")
		spinbox.value = value
		
		spinbox.step = 0.1 if value is float else 1.0
		spinbox.allow_greater = true if value is int else false
		spinbox.max_value = 250 if value is int else 1
		spinbox.value_changed.connect(func(v): rerender(key, v))
func rerender(key: String, value):
	pjd.theme[key] = value
	%Commander.rerender()
	rerenderstaves()
	#for container in %Staves.get_children():
		#for line in container.get_children():
			#line.self_modulate = pjd.theme[container.name]
	if key == "bg":
		%Background.default_color = value
func rerenderstaves():
	for line in %Staves.get_children():
		line.free()
	for stave in pjd.project.staves:
		%ChordRenderer.renderstave(stave)
