extends Node

@export var pjd: Node
@export var editor: Node
@export var playbacker: Node
@export var renderer: Node
@export var chords: Node2D
@export var windows: CanvasLayer
signal audio_loaded
var filename := ""
var curpath := ""

var commands = {
	"new": func():
		pjd.project = {
			"songpath": "",
			"bpm": 130.0,
			"time_sig": [4, 4],
			"chords": [],
			"staves": ["", "2+"]
		}
		playbacker.curbeat = 0
		editor.editingid = -1
		rerender()
		editor.buildclips()
		%Music.stream = AudioStreamMP3.new()
		%Grid.queue_redraw()
		pjd.nextid = 0
		rerenderstaves()
		filename = ""
		curpath = "",
	"save": func():
		save(pjd.project, "shp"),
	"save_as": func():
		curpath = ""
		save(pjd.project, "shp"),
	"export_theme": func():
		save(pjd.theme, "shm"),
	"new_clip": func():
		createclip(""),
	"delete_clip": func():
		var id = editor.editingid
		if id != null:
			pjd.removechord(id)
			editor.deleteclip(id)
			rerender(),
	"duplicate_selected": func():
		var chord = pjd.getchord(editor.editingid)
		if chord != null:
			createclip(chord.formula),
	"duplicate_last": func():
		var chord = pjd.getchord(playbacker.active)
		if chord != null:
			createclip(chord.formula),
	#"play_pause": func():
	#	playbacker.playing = !playbacker.playing,
	"focus": func():
		playbacker.tp(Vector2(renderer.getchordcenter(editor.editingid).x, 000)),
	"previous_clip": func():
		if pjd.project.chords.is_empty(): return
		var chord = pjd.project.chords[pjd.idtoindex(editor.editingid) - 1]
		editor.selectclip(chord.id)
		editor.setbeat(chord.start)
		playbacker.curbeat = chord.start,
	"next_clip": func():
		if pjd.project.chords.is_empty(): return
		var chord = pjd.project.chords[ #modulo so it wraps
			(pjd.idtoindex(editor.editingid)+1) % pjd.project.chords.size()]
		editor.selectclip(chord.id)
		editor.setbeat(chord.start)
		playbacker.curbeat = chord.start,
	"zoom_in": func():
		editor.ppb *= 1.1
		@warning_ignore("unused_variable")
		var way_through = float(%Timeline.scroll_horizontal + %Timeline.size.x/2) / %Content.custom_minimum_size.x
		%Content.custom_minimum_size.x = editor.beat_to_x(%Music.stream.get_length() / (60.0 / pjd.project.bpm))
		#%Timeline.scroll_horizontal = %Content.custom_minimum_size.x * way_through
		editor.repositionclips(),
	"zoom_out": func():
		var old_size = %Content.custom_minimum_size.x
		var new_size = max(%Timeline.size.x, editor.beat_to_x(%Music.stream.get_length() / (60.0 / pjd.project.bpm)))
		#if new_size > old_size:
		editor.ppb /= 1.1
		@warning_ignore("unused_variable")
		var way_through = float(%Timeline.scroll_horizontal + %Timeline.size.x/2) / old_size
		%Content.custom_minimum_size.x = new_size
		#%Timeline.scroll_horizontal = new_size * way_through
		editor.repositionclips(),
		
	"project_info": func():
		windows.get_node("ProjectInfo").popup(),
	"edit_theme": func():
		windows.get_node("ThemeEditor").popup(),
	"edit_staves": func():
		windows.get_node("StaveEditor").popup(),
	"github": func():
		OS.shell_open("https://github.com/GranderUtai/shaccord")
}

func run(command: String):
	if commands.has(command):
		commands[command].call()
	else:
		push_error("un kown komand " + command)
func createclip(formula: String):
	var id = pjd.addchord(formula, playbacker.curbeat)
	editor.addclip(pjd.getchord(id))
	rerender()
	return id
func rerender():
	for node in chords.get_children():
		node.free()
	for chord in pjd.project.chords:
		pjd.render(pjd.dechordonym(chord.formula),chord.id)
func rerenderstaves():
	for line in %Staves.get_children():
		line.free()
	for stave in pjd.project.staves:
		%ChordRenderer.renderstave(stave)
func _input(event):
	if get_viewport().gui_get_focus_owner() is LineEdit: return
	for command in commands:
		if InputMap.has_action(command) and event.is_action_pressed(command):
			run(command)
			Log.pr("DOING", command)
			break
func save(dict: Dictionary, ext: String) -> void:
	# Always show dialog for .shm files or if no path set (new save)
	if ext == "shm" or curpath == "":
		var dialog = FileDialog.new()
		add_child(dialog)
		dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
		dialog.filters = ["*.shm ; Shaccord Theme"] if ext == "shm" else ["*.shp ; Shaccord Project"]
		dialog.popup_centered_ratio(0.7)
		dialog.file_selected.connect(func(path):
			do_save_fr(dict, path)
			curpath = path
			)
		return
	
	# For existing files, show confirmation dialog
	var confirm = ConfirmationDialog.new()
	add_child(confirm)
	confirm.title = "Overwrite File?"
	confirm.dialog_text = "Are you sure you want to overwrite:\n" + curpath
	confirm.confirmed.connect(func():
		do_save_fr(dict, curpath)
	)
	confirm.popup_centered_ratio(0.5)

func do_save_fr(dict: Dictionary, path: String) -> void:
	var json_dict = _colors_to_hex(dict)
	var json_string = JSON.stringify(json_dict, "\t")
	
	var file = FileAccess.open(path, FileAccess.WRITE)
	if file:
		file.store_string(json_string)
		Log.pr("Saved to: ", path)
	else:
		Log.pr("ERROR: Could not save to ", path)

func _colors_to_hex(dict: Dictionary) -> Dictionary:
	var result = {}
	for key in dict:
		var value = dict[key]
		if value is Color:
			result[key] = value.to_html()  # Convert Color to hex string like "524E61"
		else:
			result[key] = value
	return result
var menus = {
	"File": [
		"new", "!open",
		"", "save", "save_as", "!load_audio",
		"!import_theme", "export_theme"],
	"Edit": [
		"!undo", "!redo",
		"", "!cut", "!copy", "!paste", "delete",
		"", "new_clip", "duplicate_last", "duplicate_selected",
		"", "previous_clip", "next_clip", "focus",
		"", "zoom_in", "zoom_out", "!change_snap"],
	"Playback": [
		"!play_pause", "!restart",
		"", "!back_measure", "!next_measure",
		"", "!anim_styles", "!render_playback"],
	"Project": [
		"project_info",
		"", "edit_theme", "edit_staves"],
	"Help": [
		"github", "!docs",
		"", "!credits", "!about"]
}

@export var menubar: MenuBar
func _ready() -> void:
	for tab in menus:
		var options = menus[tab]
		var popup = PopupMenu.new()
		popup.name = str(tab).capitalize()
		menubar.add_child(popup)
		popup.id_pressed.connect(_on_item_pressed.bind(popup))
		var item_id = 0 
		for option in options:
			if option == "" or option.begins_with("-"):
				popup.add_separator(option.trim_prefix("-"))
			else:
				var is_disabled = option.begins_with("!")
				var label = option.trim_prefix("!")
				popup.add_item(label, item_id)
				popup.set_item_metadata(popup.get_item_index(item_id), option.trim_prefix("!"))
				if is_disabled:
					popup.set_item_disabled(popup.get_item_index(item_id), true)
				item_id += 1
	get_window().files_dropped.connect(func(files):
		if files.is_empty():
			return
		var path: String = files[0]
		var file := FileAccess.open(path, FileAccess.READ)
		var extension: String = path.get_extension().to_lower()
		match extension:
			"mp3", "wav":
				var stream
				match extension:
					"mp3": stream = AudioStreamMP3.new() 
					"wav": stream = AudioStreamWAV.new()
				stream.data = file.get_buffer(file.get_length())
				%Music.stream = stream
				pjd.project.songpath = path
				audio_loaded.emit()
			"shp":
				var j = JSON.parse_string(FileAccess.get_file_as_string(path))
				for key in j:
					var value = j[key]
					pjd.project[key] = value
				for chord in pjd.project.chords:
					chord.id = int(chord.id)
				playbacker.curbeat = 0
				editor.editingid = -1
				rerender()
				editor.buildclips()
				rerenderstaves()
				var stream
				Log.pr("project audio is", pjd.project.songpath, pjd.project.songpath.get_extension().to_lower())
				match pjd.project.songpath.get_extension().to_lower():
					"mp3": stream = AudioStreamMP3.new() 
					"wav": stream = AudioStreamWAV.new()
				var audio = FileAccess.open(pjd.project.songpath, FileAccess.READ)
				stream.data = audio.get_buffer(audio.get_length())
				%Music.stream = stream
				audio_loaded.emit()
				Log.pr("loaded proj", path)
			"shm":
				var t = JSON.parse_string(FileAccess.get_file_as_string(path))
				for key in t:
					var value = t[key]
					if value is String:
						if value.contains("("):
							var cleaned = value.replace("(", "").replace(")", "")
							var colors = cleaned.split(", ", false)
							pjd.theme[key] = Color(float(colors[0]), float(colors[1]), float(colors[2]), float(colors[3]))
						else: pjd.theme[key] = Color.from_string(value, Color.OLIVE)
					else:
						pjd.theme[key] = value
				#pjd.theme = t
				rerender()
				for container in %Staves.get_children():
					container.modulate.a = pjd.theme.stave_opacity
					for line in container.get_children():
						line.self_modulate = pjd.theme[container.name]
				%Background.default_color = pjd.theme.bg
				Log.pr("loaded thehe", path)
			"shx":
				print("load project and theme")
		)

func _on_item_pressed(id: int, popup: PopupMenu) -> void:
	var idx = popup.get_item_index(id)
	var option = popup.get_item_metadata(idx)
	run(option)
