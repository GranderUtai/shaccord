extends Node

@export var pjd: Node
@export var playbacker: Node

@export var timeline: ScrollContainer
@export var inp: LineEdit
@export var content: Control
@export var grid: Control
@export var clips: Control
@export var cursor: Control
@export var music: AudioStreamPlayer2D

@export var selection := []
@export var editingid = null
var snap := 0.5
@export var ppb := 40.0
var songlength = 0.0
var startx := 0.0
func _ready():
	buildclips()
	%Commander.audio_loaded.connect(func():
		songlength = music.stream.get_length()
		grid.queue_redraw()
		content.custom_minimum_size.x = beat_to_x(songlength / (60/pjd.project.bpm))
		)
	inp.text_changed.connect(func(formula):
		if editingid != null:
			pjd.updatechord(editingid, {"formula": formula})
			pjd.render(formula, editingid)
			clips.get_node(str(editingid)).text = formula
	)
	playbacker.activechanged.connect(func(index):
		for clip in clips.get_children():
			if clips.get_children().is_empty() or index == -1: return
			if clip.name == str(pjd.project.chords[index].id):
				clip.modulate = Color.from_rgba8(0, 255, 255, 255)
				clip.z_index = 1
			else:
				clip.modulate = Color.from_rgba8(255, 255, 255, 255)
				clip.z_index = 0
	)
	cursor.get_node("Line/Handle").dragstart.connect(func():
		startx = cursor.global_position.x
	)
	cursor.get_node("Line/Handle").dragged.connect(func(wishx):
		var target = x_to_beat(wishx+startx+timeline.scroll_horizontal)
		if target < 0: target = 0
		playbacker.curbeat = snapped(target, snap)
		setbeat(playbacker.curbeat)
	)
## clip stuff
func buildclips():
	for c in clips.get_children():
		if c.name != "sample":
			c.free()
	for chord in pjd.project.chords:
		addclip(chord)
	clips.get_node("sample").visible = false
	grid.queue_redraw()
func addclip(chord):
	var new = clips.get_node("sample").duplicate()
	new.name = str(chord.id)
	new.text = chord.formula
	new.position.x = beat_to_x(chord.start)
	new.visible = true
	clips.add_child(new)
	selectclip(chord.id)
	new.pressed.connect(func(): #### CLICKED A CLIP ####
		Log.pr("clicked clip named", new.name)
		selectclip(chord.id)
	)
func deleteclip(id):
	if editingid != null or selection != []:
		clips.get_node(str(id)).queue_free()
		editingid = null
func selectclip(id):
	if id == -1:
		editingid = null
	editingid = id
	inp.text = pjd.getchord(id).formula
	for clip in clips.get_children():
		if clip.name == str(id):
			clip.self_modulate = Color.from_rgba8(152, 255, 93, 255)
			clip.z_index = 1
		else:
			clip.self_modulate = Color.from_rgba8(255, 255, 255, 255)
			clip.z_index = 0
	#inp.edit()
func repositionclips():
	setbeat(playbacker.curbeat)
	if clips.get_children().size() == 1: return
	for clip in clips.get_children():
		var target = int(clip.name.replace("_0", "")) #for some reason clips have _0 attached to them??
		if target == null: break
		clip.position.x = beat_to_x(pjd.getchord(target).start)
	grid.queue_redraw()
### cursor
func setbeat(beat: float):
	cursor.position.x = beat_to_x(beat)
func _process(_delta: float) -> void:
	if playbacker.playing:
		setbeat(playbacker.curbeat)
#### grid
func beat_to_x(beat: float) -> float:
	return beat * ppb
func x_to_beat(x: float) -> float:
	return x / ppb
func mouse_to_beat(globalx):
	var scroll = timeline.scroll_horizontal
	var localx = globalx - timeline.global_position.x + scroll
	return x_to_beat(localx)
#func _draw():
	#var visible_left = timeline.scroll_horizontal
	#var visible_right = visible_left + grid.size.x
#
	#var start_beat = int(x_to_beat(visible_left))
	#var end_beat = int(x_to_beat(visible_right)) + 1
#
	#for b in range(start_beat, end_beat):
		#var x = beat_to_x(b) - visible_left
		#var downbeat = b % pjd.project.time_sig[0] == 0
		#grid.draw_line(
			#Vector2(x, 0),
			#Vector2(x, grid.size.y),
			#Color(0, 0, 0, 0.6 if downbeat else 0.3),
			#2 if downbeat else 1
		#)
