extends Node

@export var camera: Camera2D
@export var pjd: Node
@export var renderer: Node
@export var music: AudioStreamPlayer2D
@export var metronome_player: AudioStreamPlayer2D

var last_active_index := -1
var last_metronome_beat := -1

@export var curbeat := 0.0
@export var active: int

@export var playing := false
@export var metronome := false

signal activechanged
var songlength = 0

func tp(pos: Vector2):
	camera.position_smoothing_enabled = false
	var p = camera.position_smoothing_speed
	camera.position_smoothing_speed = 9999
	camera.position = pos
	camera.position_smoothing_speed = p
	camera.position_smoothing_enabled = true

func btos(beat: float) -> float:
	return (60.0 / pjd.project.bpm) * beat

func tweento(pos: Vector2, time: float):
	var tween: Tween = create_tween()
	tween.tween_property(camera, "position", pos, time)
	

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("play_pause"):
		playing = !playing
		if playing:
			if btos(curbeat) == songlength: curbeat = 0
			music.play(btos(curbeat))
		else:
			music.stop()
	elif Input.is_action_just_pressed("restart"):
		playing = true
		curbeat = 0.0
		last_metronome_beat = -1
		music.play(0)
		if not pjd.project.chords.is_empty():
			tp(Vector2(renderer.getchordcenter(pjd.project.chords[0].id).x, 000))
	elif Input.is_action_just_pressed("ui_right"):
		curbeat += pjd.project.time_sig[0] * 2
		if btos(curbeat) > songlength: curbeat = songlength / (60/pjd.project.bpm)
		music.seek(btos(curbeat))
	elif Input.is_action_just_pressed("ui_left"):
		curbeat -= pjd.project.time_sig[0] * 2
		if curbeat < 0: curbeat = 0
		music.seek(btos(curbeat))
	if not playing:
		return

	curbeat += delta / (60.0 / pjd.project.bpm)
	if not metronome: metronome_player.volume_linear = 0
	var beat_i := int(floor(curbeat))
	if beat_i != last_metronome_beat:
		last_metronome_beat = beat_i
		if metronome_player:
			@warning_ignore("incompatible_ternary")
			metronome_player.pitch_scale = 1.15 if beat_i % int(pjd.project.time_sig[0]) == 0 else 1
			metronome_player.play()

	active = pjd.get_active_index(curbeat)
	if active != last_active_index:
		last_active_index = active
		activechanged.emit(max(int(active), 0))

func _ready():
	activechanged.connect(_on_active_changed)
	%Commander.audio_loaded.connect(func():
		songlength = music.stream.get_length())

func _on_active_changed(activeindex: int):
	#if activeindex + 1 > pjd.project.chords.size() - 1:
	if btos(curbeat) >= songlength:
		playing = false
		music.stop()
		return
	#prob should make it not tween at all if its the last chord
	var cur = pjd.project.chords[activeindex]
	var next = pjd.project.chords[min(activeindex+1, pjd.project.chords.size()-1)]
	var pos = renderer.getchordcenter(next.id)
	var time = btos(next.start - cur.start)
	Log.pr(cur.id, "->", next.id, next.formula, "in", time, "s")
	switch.play()
	tweento(Vector2(pos.x + 30, 000), time)
@export var switch: AudioStreamPlayer2D
