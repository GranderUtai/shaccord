extends Node

@export var chordrenderer: Node
@export var Chords: Node2D
@export var Interface: CanvasLayer
@export var project = {
	"songpath": "",
	"bpm": 130.0,
	"time_sig": [4, 4],
	"chords": [],
	"staves": []
}
@export var theme = {
	"bg": Color.html("524E61"),
	"tension": Color.html("3FFFFC"),
	"tension2": Color.html("FFA2FA"),
	"pitchline": Color.html("FFFFFF"),
	"tension_opacity": 0.5,
	"stave_opacity": 0.3,
	"chord_gap": 75,
	
	"0": Color.html("FFFFFF"),
	"1": Color.html("AAAAAA"),
	"2": Color.html("F27992"),
	"3": Color.html("6CD985"),
	"4": Color.html("B598EE"),
	"5": Color.html("FFC247"),
	"6": Color.html("B5B500"),
	"7": Color.html("DF9C81"),
}
@export var nextid := 0
var chordonyms = { # %s = previous symbol in conversion result; "/%%s(%s)"
	"Ah" = "x",
	"Ju" = "2/-/--", "Schu" = "2/--", "Fu" = "2-", "Chy" = "2+", "Scy" = "2/++", "Xcy" = "2/+/++",
	"Sru" = "3/--", "Su" = "3-", "Ly" = "3+", "Dry" = "3/++",
}
func enmodifier(chnym: String) -> String:
	chnym = chnym.replace("Tshu", "k")
	chnym = chnym.replace("u", "")
	chnym = chnym.replace("i", "y")
	chnym = chnym.to_lower()
	return chnym
func dechordonym(chordonym: String) -> String:
	var formula = chordonym
	#some magic here
	#normal replace normal, modifiers replace with "/%PREVSYMBL(%FORMULA)" somehow
	for key in chordonyms:
		formula = formula.replace(key, chordonyms[key])
	for key in chordonyms:
		formula = formula.replace(enmodifier(key), "/%s("+chordonyms[key]+")") #i dont know how to do the previous symbol thing
	return formula
func sort():
	project.chords.sort_custom(
		func(a, b):
			return a.start < b.start
	)
func getchord(id: int):
	for chord in project.chords:
		if chord["id"] == id:
			return chord
	#return null
func idtoindex(id: int):
	for i in range(project.chords.size()):
		if project.chords[i].id == id:
			return i
func addchord(formula: String, beat: float) -> int:
	var id = nextid
	nextid += 1
	project.chords.append({
		"id": id,
		"formula": formula,
		"start": beat,
	})
	sort()
	return id
func removechord(id: int):
	for i in range(project.chords.size()):
		if project.chords[i]["id"] == id:
			project.chords.remove_at(i)
			break
	sort()
func updatechord(id: int, properties: Dictionary):
	var chord = getchord(id)
	for property in properties:
		var value = properties[property]
		chord[property] = value
	sort()

func render(formula, id: int):
	var chord: Node2D = chordrenderer.renderchord(dechordonym(formula), id)
	var width = 100
	var index := -1
	var updating := true
	if Chords.get_node_or_null(str(id)) == null:
		Chords.add_child(chord)
		updating = false
	for i in range(project.chords.size()):
		var ch = project.chords[i]
		if ch["id"] == id:
			index = i
			break
	if index == -1:
		Log.pr("chord id", id, "not found")
		return
	if not updating: 
		chord.position += Vector2(index * (width + theme.chord_gap), 0) 

func _ready():
	#var bar = project.time_sig[0]
	#addchord("4+2+(4+ 3v", bar*2)
	#addchord("4+2+(4+2+)", bar*3)
	#addchord("2+3+", bar*3 + 1.5)
	#addchord("2+(4+2+)4+", 0)
	#addchord("4+2++ 2v4^", bar)
#
	#
	#addchord("2+(4+2+)4+", bar*4)
	#addchord("4+2++ 2v4^", bar*5)
	#addchord("4+2+(4+ 3v", bar*6)
	#addchord("2+/+(4-) 2^^3v", bar*7)
	#addchord("2+3+", bar*7 + 1.5)
	#
	#addchord("2+(4+2+)4+", bar*8 + 2)
	#addchord("4+2++ 2v4^", bar*9 + 2)
	#addchord("4+2+(4+ 3v", bar*10 + 2)
	#addchord("4+2+(4+2+)", bar*11 + 2)
	#addchord("2+3+", bar*11 + 1.5 + 2)
	#
	#addchord("2+(4+2+)4+", bar*12 + 2)
	#addchord("4+2++ 2v4^", bar*13 + 2)
	#addchord("4+2+(4+ 3v", bar*14 + 2)
	#addchord("2+/+(4-) 2^^3v", bar*15 + 2)
	#addchord("2+3+", bar*15 + 1.5 + 2)
	#
	#addchord("3+2+(3+2+) 2^^5v", bar*16 + 4)
	#addchord("2+3+4+(2-) 5v", bar*17 + 0 + 4)
	#addchord("2+3+4+(2-)/2-(6+) 5v", bar*17 + 1.5 + 4)
	#addchord("2+3+4+ 5v", bar*17 + 2.5 + 4)
	###
	#addchord("2+6+(2-) 2vv5^", bar*18 + 4)
	#addchord("/2+(3+)+5+ 2^3v", bar*19 + 4)
	###
	#addchord("3+2+(3+2+) 2^^5v", bar*20 + 4)
	#addchord("2+3+4+(2-) 5v", bar*21 + 0 + 4)
	#addchord("2+3+4+(2-)/2-(6+) 5v", bar*21 + 1.5 + 4)
	#addchord("2+3+4+ 5v", bar*21 + 2.5 + 4)
	###
	#addchord("2+(3-2+ 2v", bar*22 + 4)
	#addchord("2+(3-2+ 2^", bar*22 + 2.5 + 4)
	#addchord("2++5+ 5v", bar*23 + 4)
	#addchord("2++5+(2--) 5v", bar*24 + 6)
	#
	#addchord("2+(4+2+)4+", bar*25 + 6)
	#addchord("4+2++ 2v4^", bar*26 + 6)
	#addchord("4+2+(4+ 3v", bar*27 + 6)
	#addchord("2+/+(4-) 2^^3v", bar*28 + 6)
	#addchord("2+3+", bar*28 + 1.5 + 6)
	#addchord("2+(4+2+)4+", bar*29 + 6)
	#addchord("4+2++ 2v4^", bar*30 + 6)
	#addchord("4+2+(4+ 3v", bar*31 + 6)
	#addchord("4+2+(4+2+)", bar*32 + 6)
	#addchord("2+3+", bar*32 + 1.5 + 6)
#
	#addchord("", bar*34 + 1.5 + 6)
	#Log.prn("project chords:", project.chords)
	for chord in project.chords:
		render(dechordonym(chord.formula), chord.id)
	for stave in project.staves:
		chordrenderer.renderstave(stave)

func get_active_index(beat: float) -> int:
	for i in range(project.chords.size()):
		if project.chords[i].start > beat:
			return i - 1
	return project.chords.size() - 1
