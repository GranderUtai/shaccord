extends Control

@export var editor: Node
@export var timeline: ScrollContainer
@export var content: Control
@export var music: AudioStreamPlayer2D
@export var pjd: Node

func beat_to_x(beat: float) -> float:
	return beat * editor.ppb
func x_to_beat(x: float) -> float:
	return x / editor.ppb

func _draw():
	var visible_left = timeline.scroll_horizontal
	var visible_right = visible_left + size.x

	var start_beat = int(x_to_beat(visible_left))
	var end_beat = int(x_to_beat(visible_right)) + 1

	for b in range(start_beat, end_beat):
		var x = beat_to_x(b) - visible_left
		var downbeat = b % int(pjd.project.time_sig[0]) == 0
		draw_line(
			Vector2(x, 0),
			Vector2(x, size.y),
			Color(0, 0, 0, 0.6 if downbeat else 0.3),
			2 if downbeat else 1
		)
func _ready() -> void:
	content.custom_minimum_size.x = beat_to_x(music.stream.get_length() / (60/pjd.project.bpm))
	%Commander.audio_loaded.connect(func():
		content.custom_minimum_size.x = beat_to_x(music.stream.get_length() / (60/pjd.project.bpm))
		queue_redraw()
	)
	
