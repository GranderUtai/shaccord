extends Node
@export var chords: Node
@export var staves: Node
@export var theme: Node

static var dimensions = {
	0: "1/1",
	1: "2/1",
	2: "3/2",
	3: "5/4",
	4: "7/4",
	5: "11/4",
	6: "13/4",
	7: "17/4",
}
static var ymult = 100 / log2(dratio(2))
#### math
static func qr(d:int):
	return dimensions[d] if dimensions.has(d) else dimensions[0]

static func ratio(expr: String, flip: bool = false):
	var d = expr.split("/", false)
	var first = float(d[0]) if not flip else float(d[1])
	var second = float(d[1]) if not flip else float(d[0])
	var result: float = first/second
	return result

static func dratio(d:int, flip: bool = false):
	return ratio(qr(d), flip)

static func log2(x):
	return log(x) / log(2.0)

#### data management
static func endata(formula: String):
	var curdim: int = -1
	var counter := 1
	var data = {
		"offset": {"mult": 1.0, "y": 0.0},
		"rootatts": {},
		"chord": []
	}
	var root = data.chord
	var stack = []
	var current = root
	var last_note = null
	var accatts = {}
	for i in range(formula.length()):
		var c := formula.substr(i, 1)
		match c:
			"/":
				accatts.muted = true
				continue
			">":
				accatts.bass = true
				continue
			"<":
				accatts.rbass = true
				continue
			"'":
				accatts.tension = true
				continue
			'"':
				accatts.tension2 = true
				continue
		if "R!0".find(c) != -1:
			data.rootatts = accatts
			accatts = {}
			continue
		if c.is_valid_int() and c != "0":
			curdim = int(c)
			continue
		if "+-".find(c) != -1:
			var dir := "up" if c == "+" else "down"
			var note = {
				"id": counter,
				"dimension": curdim,
				"direction": dir,
				"attributes": accatts,
				"children": []
			}
			accatts = {}
			counter += 1
			if last_note != null \
			and last_note.dimension == curdim \
			and last_note.direction == dir:
				last_note.children.append(note)
			else:
				current.append(note)
			last_note = note
			continue
		if "^v".find(c) != -1:
			if c == "^":
				data.offset.mult *= dratio(curdim)
				data.offset.y -= log2(dratio(curdim)) * ymult
			else:
				data.offset.mult *= dratio(curdim, true)
				data.offset.y += log2(dratio(curdim)) * ymult
			continue
		if c == "(":
			stack.append(current)
			if last_note != null:
				current = last_note.children
			continue
		if c == ")":
			current = stack.pop_back()
			last_note = null
			continue
	return data

func find_parent_note(id: int, data: Dictionary, current_parent = null):
	for note in data["chord"]:
		if note["id"] == id:
			return current_parent
		var found = _search_children(id, note["children"], note)
		if found != null:
			return found
	return null

func _search_children(id: int, children: Array, parent):
	for child in children:
		if child["id"] == id:
			return parent
		var found = _search_children(id, child["children"], child)
		if found != null:
			return found
	return null

#### visual
func rendernote(note, container: Node2D, base_y: float, parent_pitchline = null) :
	var dim: int = note["dimension"]
	var sigdim = -dim if note["direction"] == "down" else dim
	if dim < 0:
		print("durrr invalid dimension " + str(dim))
		return
	var color = theme.theme[str(dim)]
	var dir_sign = -1 if note["direction"] == "up" else 1
	var y = base_y + log2(dratio(dim)) * ymult * dir_sign

	var pitchline = Line2D.new()
	pitchline.points = [
		Vector2(0, y),
		Vector2(100, y)
	]
	pitchline.width = 3
	pitchline.self_modulate = theme.theme.pitchline
	pitchline.name = str(note["id"])
	#if parent_pitchline != null:
		#var psigdim = -parent_pitchline.get_meta("dimension") if parent_pitchline.get_meta("direction") == "down" else parent_pitchline.get_meta("dimension")
	var sides = {
		"start": {
			"left": [2,-2,4,-5,6,-6],
			"right": [3,-3,-4,5,7,-7]},
		"end": {
			"left": [2,-2,-4,5,6,-6],
			"right": [3,-3,4,-5,7,-7]}
	}
	var getside = func(d: int, point: String):
		for side in sides[point]:
			var array: Array = sides[point][side]
			if array.has(d): return side
	var contrasting = false
	var mainend = getside.call(sigdim, "end")
	for child in note["children"]:
		var childsigdim = -child["dimension"] if child["direction"] == "down" else child["dimension"]
		if getside.call(childsigdim, "start") != mainend:
			contrasting = true
	### ATTRIBUTES APPLYING
	var transparency = 1.0
	for attr in note.attributes:
		match str(attr):
			"muted":
				if not contrasting and len(note["children"]) > 0:
					transparency = 0
				else:
					pitchline.texture_mode = Line2D.LINE_TEXTURE_TILE
					pitchline.texture = load("res://png/pitch-line-dotted.png")
			"bass":
				var bass = $bass.duplicate()
				bass.visible = true
				bass.position = pitchline.points[0]+Vector2(-32,-10)
				pitchline.add_child(bass)
			"rbass":
				var bass = $bass.duplicate()
				bass.visible = true
				bass.rotation_degrees = 180
				bass.position = pitchline.points[1]+Vector2(32,10)
				pitchline.add_child(bass)
			"tension":
				pitchline.self_modulate = theme.theme.tension
			"tension2":
				pitchline.self_modulate = theme.theme.tension2
				
	pitchline.default_color.a = transparency
	for property in note:
		pitchline.set_meta(property, note[property])
	#match parentid:
	#	-1: container.add_child(pitchline) # called when making the root note only, so parent it straight to the chord node2d
	#	_: container.find_child(str(parentid), true).add_child(pitchline) # Cannot call method 'add_child' on a null value.

	if parent_pitchline == null:
		container.add_child(pitchline)
	else:
		parent_pitchline.add_child(pitchline)
	if parent_pitchline != null:
		var dimline = Line2D.new()
		var topline #: Line2D = pitchline if pitchline.position.y < parent_pitchline.position.y else parent_pitchline
		var bottomline #: Line2D = parent_pitchline if topline == pitchline else topline
		if pitchline.points[0].y > parent_pitchline.points[0].y:
			topline = pitchline
			bottomline = parent_pitchline
		else:
			topline = parent_pitchline
			bottomline = pitchline
		#print(bottomline, topline)
		dimline.width = 9
		var dlpoints: Array
		match dim:
			2: dlpoints = [bottomline.points[0]-Vector2(-dimline.width/2,pitchline.width/2), topline.points[0]+Vector2(dimline.width/2,pitchline.width/2)]
			3: dlpoints = [bottomline.points[1]-Vector2(dimline.width/2,pitchline.width/2), topline.points[1]+Vector2(-dimline.width/2,pitchline.width/2)]
			4: dlpoints = [bottomline.points[1]-Vector2(0,pitchline.width/2), topline.points[0]+Vector2(0,pitchline.width/2)]
			5: dlpoints = [bottomline.points[0]-Vector2(0,pitchline.width/2), topline.points[1]+Vector2(0,pitchline.width/2)]
			6: dlpoints = [bottomline.points[0]-Vector2(-dimline.width/2,pitchline.width/2), Vector2(-dimline.width-8, (bottomline.points[0].y+topline.points[1].y)/2), topline.points[0]+Vector2(dimline.width/2,pitchline.width/2)]
			_: dlpoints = [bottomline.points[0]-Vector2(dimline.width/2,pitchline.width/2), topline.points[0]+Vector2(-dimline.width/2,pitchline.width/2)]
		#Log.prn(bottomline.points, topline.points, dlpoints)
		var flippoints = dlpoints
		flippoints.reverse()
		dimline.points = dlpoints if note["direction"] == "down" else flippoints
		dimline.default_color = color
		dimline.name = str(note["dimension"]) + note["direction"]
		if note.attributes.has("tension") or note.attributes.has("tension2"):
			dimline.self_modulate.a = theme.theme.tension_opacity
		container.add_child(dimline)
		
	for child in note["children"]:
		rendernote(child, container, y, pitchline)

func renderchord(data, cid: int = -1) -> Node2D:
	var formula = data if data is String else "from data"
	var container
	if chords.get_node_or_null(str(cid)) != null:
		container = chords.get_node(str(cid))
		for child in container.get_children():
			child.queue_free()
	else:
		container = Node2D.new()
		container.name = str(cid)
	if data is String and data.strip_edges() == "":
		return container
	if data is String:
		data = endata(formula)
	var root_note = {
		"id": 0,
		"dimension": 0,
		"direction": "up",
		"attributes": data.rootatts,
		"freq": 1,
		"children": data.chord
	}
	rendernote(root_note, container, data["offset"]["y"], null)
	return container

func getchordcenter(id: int) -> Vector2:
	var chord := chords.get_node_or_null(str(id))
	if chord == null:
		push_error("no chord id " + str(id))
		return Vector2.ZERO
	var minx := INF
	var maxx := -INF
	var miny := INF
	var maxy := -INF
	var found := false
	for node in chord.find_children("*", "Line2D", true, false):
		var line := node as Line2D
		if line.points.size() < 2:
			continue
		for p in line.points:
			var gp := line.to_global(p)
			minx = min(minx, gp.x)
			maxx = max(maxx, gp.x)
			miny = min(miny, gp.y)
			maxy = max(maxy, gp.y)
			found = true
	if not found:
		push_error("chord", id, "got no pitchlines")
		return Vector2.ZERO
	return Vector2(
		(minx + maxx) * 0.5,
		(miny + maxy) * 0.5
	)

func renderstave(formula: String) -> Node2D:
	### analyzing it
	var curdim := 0
	var interval = 0 #in px
	var offset = 0 #in px
	var color = str(curdim)
	for i in range(formula.length()):
		var c := formula.substr(i, 1)
		if c.is_valid_int() and c != "0":
			curdim = int(c)
			color = str(max(int(color), curdim))
			continue
		match c:
			"+", "-":
				interval += log2(dratio(curdim)) * ymult * (-1 if c == "+" else 1)
			"^", "v":
				offset += log2(dratio(curdim)) * ymult * (-1 if c == "^" else 1)
	### rendering it
	var container = Node2D.new()
	container.name = color
	var left = -1000
	var right = 99999
	if formula == "" or "R" in formula:
		var line = Line2D.new()
		line.points = [Vector2(left, 0), Vector2(right, 0)] #make it really long
		line.width = 3 if formula == "" else 15
		line.name = "0"
		line.self_modulate = theme.theme["pitchline"]
		#line.default_color.a = theme.theme["stave_opacity"]
		container.add_child(line)
	else:
		var repeats := 50 #in each direction
		for i in range(0 if offset != 0 else 1, repeats+1): # +1 for some reason
			var line = Line2D.new()
			line.points = [Vector2(left, 0), Vector2(right, 0)] #make it really long
			line.width = 3
			line.self_modulate = theme.theme[color]
			#line.default_color.a = theme.theme["stave_opacity"]
			line.name = str(i)
			line.position.y = interval*-i + offset
			container.add_child(line)
			if i != 0: #prevent it from duplicating the 0th line
				var lowline = line.duplicate()
				lowline.position.y = line.position.y*-1 + offset*2 #since it revolves around y=0
				#lowline.name = "-"+lowline.name        ^ double the offset so its not inverted
				container.add_child(lowline)           
	staves.add_child(container)
	container.modulate.a = theme.theme["stave_opacity"]
	return container

#biggest script i ever wrutten
