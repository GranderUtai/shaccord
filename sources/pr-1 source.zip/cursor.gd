extends TextureButton

var is_dragging := false
var startx = 0
signal dragged(wishx: float)
signal dragstart
signal dragend
func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				is_dragging = true
				dragstart.emit()
				startx = get_global_mouse_position().x
				accept_event()
			else:
				is_dragging = false
				dragend.emit()

	elif event is InputEventMouseMotion and is_dragging:
		var delta = get_global_mouse_position().x - startx
		dragged.emit(#clamp(
			delta#,
			#get_parent().get_parent().get_parent().get_node("Grid").global_position.x, 99999
		)#)
