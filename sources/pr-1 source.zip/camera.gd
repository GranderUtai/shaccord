extends Camera2D

var dragging = false
var drag_start_position = Vector2.ZERO

func _unhandled_input(event):
	# Start dragging
	if event.is_action_pressed("lmb"):
		dragging = true
		# Store the initial mouse position in global coordinates
		drag_start_position = get_global_mouse_position()
	
	# Stop dragging
	if event.is_action_released("lmb"):
		dragging = false

	# Pan the camera while dragging
	if dragging and event is InputEventMouseMotion:
		# Calculate the gap/difference from the start position to the current position
		var gap = drag_start_position - get_global_mouse_position()
		# Move the camera's global position by the calculated gap
		# Note: 'global_position' is used in Godot 4.x, or 'position' depending on your scene tree setup
		position += gap
		# Update the drag start position to the current position for smooth continuous dragging
		drag_start_position = get_global_mouse_position()
@warning_ignore("unused_parameter")
func _process(delta: float) -> void:
	%Background.position = position
